var require = meteorInstall({"lib":{"collections.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// lib/collections.js                                                                   //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
Rooms = new Mongo.Collection("rooms");
/*채팅방 컬렉션*/

Messages = new Mongo.Collection("messages");
/*채팅 메세지 컬렉션*/
//////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// lib/methods.js                                                                       //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
Meteor.methods({
  insertMessage(messageObject) {
    if (Meteor.isClient) {
      messageObject["isClient"] = true;
    }

    Messages.insert(messageObject);
    /* 시간필드 업데이트 */

    Rooms.update({
      _id: messageObject.roomId
    }, {
      $set: {
        lastMessageTime: messageObject.timestamp
      }
    });
  }

});
//////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"permission":{"facebook.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/permission/facebook.js                                                        //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
ServiceConfiguration.configurations.remove({
  service: 'facebook'
});
ServiceConfiguration.configurations.insert({
  service: 'facebook',
  appId: '1821468421257980',
  secret: 'e42d27e3ac5521ec4cb64119fb83d980'
});
//////////////////////////////////////////////////////////////////////////////////////////

},"google.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/permission/google.js                                                          //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
ServiceConfiguration.configurations.remove({
  service: 'google'
});
ServiceConfiguration.configurations.insert({
  service: 'google',
  clientId: '387316554797-n49qvjdh82tia3gbhs42n62sp2f0mt41.apps.googleusercontent.com',
  secret: 'pkUPz7Q99gl2rImMBUJa4BnD'
});
//////////////////////////////////////////////////////////////////////////////////////////

}},"allow.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/allow.js                                                                      //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
Rooms.allow({
  insert(userId, doc) {
    return userId && doc.owner === userId;
  }

});
/* 추가 */

Messages.allow({
  insert(userId, doc) {
    return userId && doc.owner === userId;
  }

});
//////////////////////////////////////////////////////////////////////////////////////////

},"fixture.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/fixture.js                                                                    //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
Meteor.startup(() => {
  if (!Rooms.findOne({
    _id: "MeteorSchool"
  })) {
    /*사용자 등록*/
    var usr1 = Accounts.createUser({
      username: "와글이",
      email: "waggle@gmail.com",
      password: "12345678"
    });
    var usr2 = Accounts.createUser({
      username: "수다쟁이",
      email: "ppillip@gmail.com",
      password: "dnflemf"
    });
    /*채팅방 등록*/

    Rooms.insert({
      _id: "MeteorSchool",
      name: "MeteorSchool",
      owner: usr1,

      /* 방장은 와글이 */
      userList: [usr1, usr2],

      /* 채팅방 참여자 */
      createdAt: new Date().getTime()
    });
  }
});
//////////////////////////////////////////////////////////////////////////////////////////

},"publish.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/publish.js                                                                    //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
Meteor.publish("roomList", function () {
  return Rooms.find();
});
Meteor.publish("messages", function (roomId, count) {
  if (!roomId) {
    console.error("채팅방 식별자 부재", count);
    return [];
  } else {
    return Messages.find({
      roomId: roomId
    }, {
      sort: {
        timestamp: -1
      },
      limit: count
    });
  }
});
Meteor.publish("userData", function () {
  return Meteor.users.find();
}); //
// // 특정 채팅방 publish
// Meteor.publish("room",function(roomId){
//     return Rooms.find({_id:roomId});
// });
//////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// server/main.js                                                                       //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
Meteor.startup(() => {});
Accounts.onCreateUser(function (options, user) {
  if (user.services.facebook) {
    user.username = user.services.facebook.name;
    user.emails = user.services.facebook.email;
  } else if (user.services.google) {
    user.username = user.services.google.name;
    user.emails = user.services.google.email;
  }

  return user;
});
//////////////////////////////////////////////////////////////////////////////////////////

}},"app-deploy":{"mup.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////
//                                                                                      //
// app-deploy/mup.js                                                                    //
//                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////
                                                                                        //
module.exports = {
  servers: {
    one: {
      // TODO: set host address, username, and authentication method
      host: '54.250.44.234',
      username: 'ubuntu',
      pem: '../waggle1.pem' // password: 'server-password'
      // or neither for authenticate from ssh-agent

    }
  },
  app: {
    // TODO: change app name and path
    name: 'waggleChat',
    path: '../',
    servers: {
      one: {}
    },
    buildOptions: {
      serverOnly: true
    },
    env: {
      // TODO: Change to your app's url
      // If you are using ssl, it needs to start with https://
      ROOT_URL: 'http://ec2-54-250-44-234.ap-northeast-1.compute.amazonaws.com',
      MONGO_URL: 'mongodb://joe1220:c159789c@ds121898.mlab.com:21898/wagglechat'
    },
    // ssl: { // (optional)
    //   // Enables let's encrypt (optional)
    //   autogenerate: {
    //     email: 'email.address@domain.com',
    //     // comma separated list of domains
    //     domains: 'website.com,www.website.com'
    //   }
    // },
    docker: {
      // change to 'abernix/meteord:base' if your app is using Meteor 1.4 - 1.5
      image: 'abernix/meteord:node-8.4.0-base'
    },
    // Show progress bar while uploading bundle to server
    // You might need to disable it on CI servers
    enableUploadProgressBar: true
  },
  mongo: {
    version: '3.4.1',
    servers: {
      one: {}
    }
  }
};
//////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/lib/collections.js");
require("/lib/methods.js");
require("/server/permission/facebook.js");
require("/server/permission/google.js");
require("/app-deploy/mup.js");
require("/server/allow.js");
require("/server/fixture.js");
require("/server/publish.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvbGliL2NvbGxlY3Rpb25zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9saWIvbWV0aG9kcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3Blcm1pc3Npb24vZmFjZWJvb2suanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9wZXJtaXNzaW9uL2dvb2dsZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2FsbG93LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvZml4dHVyZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3B1Ymxpc2guanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9hcHAtZGVwbG95L211cC5qcyJdLCJuYW1lcyI6WyJSb29tcyIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsIk1lc3NhZ2VzIiwiTWV0ZW9yIiwibWV0aG9kcyIsImluc2VydE1lc3NhZ2UiLCJtZXNzYWdlT2JqZWN0IiwiaXNDbGllbnQiLCJpbnNlcnQiLCJ1cGRhdGUiLCJfaWQiLCJyb29tSWQiLCIkc2V0IiwibGFzdE1lc3NhZ2VUaW1lIiwidGltZXN0YW1wIiwiU2VydmljZUNvbmZpZ3VyYXRpb24iLCJjb25maWd1cmF0aW9ucyIsInJlbW92ZSIsInNlcnZpY2UiLCJhcHBJZCIsInNlY3JldCIsImNsaWVudElkIiwiYWxsb3ciLCJ1c2VySWQiLCJkb2MiLCJvd25lciIsInN0YXJ0dXAiLCJmaW5kT25lIiwidXNyMSIsIkFjY291bnRzIiwiY3JlYXRlVXNlciIsInVzZXJuYW1lIiwiZW1haWwiLCJwYXNzd29yZCIsInVzcjIiLCJuYW1lIiwidXNlckxpc3QiLCJjcmVhdGVkQXQiLCJEYXRlIiwiZ2V0VGltZSIsInB1Ymxpc2giLCJmaW5kIiwiY291bnQiLCJjb25zb2xlIiwiZXJyb3IiLCJzb3J0IiwibGltaXQiLCJ1c2VycyIsIm1vZHVsZSIsIndhdGNoIiwicmVxdWlyZSIsInYiLCJvbkNyZWF0ZVVzZXIiLCJvcHRpb25zIiwidXNlciIsInNlcnZpY2VzIiwiZmFjZWJvb2siLCJlbWFpbHMiLCJnb29nbGUiLCJleHBvcnRzIiwic2VydmVycyIsIm9uZSIsImhvc3QiLCJwZW0iLCJhcHAiLCJwYXRoIiwiYnVpbGRPcHRpb25zIiwic2VydmVyT25seSIsImVudiIsIlJPT1RfVVJMIiwiTU9OR09fVVJMIiwiZG9ja2VyIiwiaW1hZ2UiLCJlbmFibGVVcGxvYWRQcm9ncmVzc0JhciIsIm1vbmdvIiwidmVyc2lvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFDQUEsUUFBUSxJQUFJQyxNQUFNQyxVQUFWLENBQXFCLE9BQXJCLENBQVI7QUFBOEM7O0FBRTlDQyxXQUFXLElBQUlGLE1BQU1DLFVBQVYsQ0FBcUIsVUFBckIsQ0FBWDtBQUE4QyxjOzs7Ozs7Ozs7OztBQ0Y5Q0UsT0FBT0MsT0FBUCxDQUFlO0FBQ1hDLGdCQUFjQyxhQUFkLEVBQTRCO0FBQ3hCLFFBQUdILE9BQU9JLFFBQVYsRUFBbUI7QUFDZkQsb0JBQWMsVUFBZCxJQUE0QixJQUE1QjtBQUNIOztBQUNESixhQUFTTSxNQUFULENBQWdCRixhQUFoQjtBQUVBOztBQUNBUCxVQUFNVSxNQUFOLENBQWE7QUFBQ0MsV0FBSUosY0FBY0s7QUFBbkIsS0FBYixFQUF3QztBQUNwQ0MsWUFBTztBQUFDQyx5QkFBZ0JQLGNBQWNRO0FBQS9CO0FBRDZCLEtBQXhDO0FBR0g7O0FBWFUsQ0FBZixFOzs7Ozs7Ozs7OztBQ0RBQyxxQkFBcUJDLGNBQXJCLENBQW9DQyxNQUFwQyxDQUEyQztBQUN2Q0MsV0FBUztBQUQ4QixDQUEzQztBQUlBSCxxQkFBcUJDLGNBQXJCLENBQW9DUixNQUFwQyxDQUEyQztBQUN2Q1UsV0FBUyxVQUQ4QjtBQUV2Q0MsU0FBTyxrQkFGZ0M7QUFHdkNDLFVBQVE7QUFIK0IsQ0FBM0MsRTs7Ozs7Ozs7Ozs7QUNKQUwscUJBQXFCQyxjQUFyQixDQUFvQ0MsTUFBcEMsQ0FBMkM7QUFDdkNDLFdBQVM7QUFEOEIsQ0FBM0M7QUFJQUgscUJBQXFCQyxjQUFyQixDQUFvQ1IsTUFBcEMsQ0FBMkM7QUFDdkNVLFdBQVMsUUFEOEI7QUFFdkNHLFlBQVUsMEVBRjZCO0FBR3ZDRCxVQUFRO0FBSCtCLENBQTNDLEU7Ozs7Ozs7Ozs7O0FDSEFyQixNQUFNdUIsS0FBTixDQUFZO0FBQ1JkLFNBQVFlLE1BQVIsRUFBZ0JDLEdBQWhCLEVBQXFCO0FBQ2pCLFdBQVFELFVBQVVDLElBQUlDLEtBQUosS0FBY0YsTUFBaEM7QUFDSDs7QUFITyxDQUFaO0FBTUE7O0FBQ0FyQixTQUFTb0IsS0FBVCxDQUFlO0FBQ1hkLFNBQVFlLE1BQVIsRUFBZ0JDLEdBQWhCLEVBQXFCO0FBQ2pCLFdBQVFELFVBQVVDLElBQUlDLEtBQUosS0FBY0YsTUFBaEM7QUFDSDs7QUFIVSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDUEFwQixPQUFPdUIsT0FBUCxDQUFlLE1BQUk7QUFFZixNQUFHLENBQUMzQixNQUFNNEIsT0FBTixDQUFjO0FBQUNqQixTQUFJO0FBQUwsR0FBZCxDQUFKLEVBQXlDO0FBRXJDO0FBQ0EsUUFBSWtCLE9BQU9DLFNBQVNDLFVBQVQsQ0FBb0I7QUFDM0JDLGdCQUFXLEtBRGdCO0FBRTNCQyxhQUFRLGtCQUZtQjtBQUczQkMsZ0JBQVc7QUFIZ0IsS0FBcEIsQ0FBWDtBQUtBLFFBQUlDLE9BQU9MLFNBQVNDLFVBQVQsQ0FBb0I7QUFDM0JDLGdCQUFXLE1BRGdCO0FBRTNCQyxhQUFRLG1CQUZtQjtBQUczQkMsZ0JBQVc7QUFIZ0IsS0FBcEIsQ0FBWDtBQU1BOztBQUNBbEMsVUFBTVMsTUFBTixDQUFhO0FBQ1RFLFdBQU0sY0FERztBQUVUeUIsWUFBTSxjQUZHO0FBR1RWLGFBQU9HLElBSEU7O0FBR2U7QUFDeEJRLGdCQUFXLENBQUNSLElBQUQsRUFBTU0sSUFBTixDQUpGOztBQUlrQjtBQUMzQkcsaUJBQWEsSUFBSUMsSUFBSixFQUFELENBQWFDLE9BQWI7QUFMSCxLQUFiO0FBUUg7QUFFSixDQTNCRCxFOzs7Ozs7Ozs7OztBQ0FBcEMsT0FBT3FDLE9BQVAsQ0FBZSxVQUFmLEVBQTBCLFlBQVU7QUFDaEMsU0FBT3pDLE1BQU0wQyxJQUFOLEVBQVA7QUFDSCxDQUZEO0FBSUF0QyxPQUFPcUMsT0FBUCxDQUFlLFVBQWYsRUFBMEIsVUFBUzdCLE1BQVQsRUFBZ0IrQixLQUFoQixFQUFzQjtBQUM1QyxNQUFHLENBQUMvQixNQUFKLEVBQVc7QUFDUGdDLFlBQVFDLEtBQVIsQ0FBYyxZQUFkLEVBQTJCRixLQUEzQjtBQUNBLFdBQU8sRUFBUDtBQUNILEdBSEQsTUFHSztBQUNELFdBQU94QyxTQUFTdUMsSUFBVCxDQUFjO0FBQUM5QixjQUFPQTtBQUFSLEtBQWQsRUFBOEI7QUFBQ2tDLFlBQU07QUFBQy9CLG1CQUFXLENBQUM7QUFBYixPQUFQO0FBQXdCZ0MsYUFBTUo7QUFBOUIsS0FBOUIsQ0FBUDtBQUNIO0FBQ0osQ0FQRDtBQVNBdkMsT0FBT3FDLE9BQVAsQ0FBZSxVQUFmLEVBQTJCLFlBQVk7QUFDbkMsU0FBT3JDLE9BQU80QyxLQUFQLENBQWFOLElBQWIsRUFBUDtBQUNILENBRkQsRSxDQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTTs7Ozs7Ozs7Ozs7QUNyQkEsSUFBSXRDLE1BQUo7QUFBVzZDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQy9DLFNBQU9nRCxDQUFQLEVBQVM7QUFBQ2hELGFBQU9nRCxDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBRVhoRCxPQUFPdUIsT0FBUCxDQUFlLE1BQU0sQ0FFcEIsQ0FGRDtBQUlBRyxTQUFTdUIsWUFBVCxDQUFzQixVQUFVQyxPQUFWLEVBQW1CQyxJQUFuQixFQUF5QjtBQUUzQyxNQUFHQSxLQUFLQyxRQUFMLENBQWNDLFFBQWpCLEVBQTJCO0FBQ3pCRixTQUFLdkIsUUFBTCxHQUFnQnVCLEtBQUtDLFFBQUwsQ0FBY0MsUUFBZCxDQUF1QnJCLElBQXZDO0FBQ0FtQixTQUFLRyxNQUFMLEdBQWNILEtBQUtDLFFBQUwsQ0FBY0MsUUFBZCxDQUF1QnhCLEtBQXJDO0FBQ0QsR0FIRCxNQUdPLElBQUdzQixLQUFLQyxRQUFMLENBQWNHLE1BQWpCLEVBQXlCO0FBQzlCSixTQUFLdkIsUUFBTCxHQUFnQnVCLEtBQUtDLFFBQUwsQ0FBY0csTUFBZCxDQUFxQnZCLElBQXJDO0FBQ0FtQixTQUFLRyxNQUFMLEdBQWNILEtBQUtDLFFBQUwsQ0FBY0csTUFBZCxDQUFxQjFCLEtBQW5DO0FBQ0Q7O0FBQ0QsU0FBT3NCLElBQVA7QUFDSCxDQVZELEU7Ozs7Ozs7Ozs7O0FDTkFOLE9BQU9XLE9BQVAsR0FBaUI7QUFDZkMsV0FBUztBQUNQQyxTQUFLO0FBQ0g7QUFDQUMsWUFBTSxlQUZIO0FBR0gvQixnQkFBVSxRQUhQO0FBSUhnQyxXQUFLLGdCQUpGLENBS0g7QUFDQTs7QUFORztBQURFLEdBRE07QUFZZkMsT0FBSztBQUNIO0FBQ0E3QixVQUFNLFlBRkg7QUFHSDhCLFVBQU0sS0FISDtBQUtITCxhQUFTO0FBQ1BDLFdBQUs7QUFERSxLQUxOO0FBU0hLLGtCQUFjO0FBQ1pDLGtCQUFZO0FBREEsS0FUWDtBQWFIQyxTQUFLO0FBQ0g7QUFDQTtBQUNBQyxnQkFBVSwrREFIUDtBQUlIQyxpQkFBVztBQUpSLEtBYkY7QUFvQkg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQyxZQUFRO0FBQ047QUFDQUMsYUFBTztBQUZELEtBN0JMO0FBa0NIO0FBQ0E7QUFDQUMsNkJBQXlCO0FBcEN0QixHQVpVO0FBbURmQyxTQUFPO0FBQ0xDLGFBQVMsT0FESjtBQUVMZixhQUFTO0FBQ1BDLFdBQUs7QUFERTtBQUZKO0FBbkRRLENBQWpCLEMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxuUm9vbXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcInJvb21zXCIpOyAgICAgICAgLyrssYTtjIXrsKkg7Lus66CJ7IWYKi9cblxuTWVzc2FnZXMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihcIm1lc3NhZ2VzXCIpOyAgLyrssYTtjIUg66mU7IS47KeAIOy7rOugieyFmCovXG4iLCJcbk1ldGVvci5tZXRob2RzKHtcbiAgICBpbnNlcnRNZXNzYWdlKG1lc3NhZ2VPYmplY3Qpe1xuICAgICAgICBpZihNZXRlb3IuaXNDbGllbnQpe1xuICAgICAgICAgICAgbWVzc2FnZU9iamVjdFtcImlzQ2xpZW50XCJdID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBNZXNzYWdlcy5pbnNlcnQobWVzc2FnZU9iamVjdCk7XG5cbiAgICAgICAgLyog7Iuc6rCE7ZWE65OcIOyXheuNsOydtO2KuCAqL1xuICAgICAgICBSb29tcy51cGRhdGUoe19pZDptZXNzYWdlT2JqZWN0LnJvb21JZH0se1xuICAgICAgICAgICAgJHNldCA6IHtsYXN0TWVzc2FnZVRpbWU6bWVzc2FnZU9iamVjdC50aW1lc3RhbXB9XG4gICAgICAgIH0pO1xuICAgIH1cbn0pO1xuIiwiU2VydmljZUNvbmZpZ3VyYXRpb24uY29uZmlndXJhdGlvbnMucmVtb3ZlKHtcbiAgICBzZXJ2aWNlOiAnZmFjZWJvb2snXG59KTtcblxuU2VydmljZUNvbmZpZ3VyYXRpb24uY29uZmlndXJhdGlvbnMuaW5zZXJ0KHtcbiAgICBzZXJ2aWNlOiAnZmFjZWJvb2snLFxuICAgIGFwcElkOiAnMTgyMTQ2ODQyMTI1Nzk4MCcsXG4gICAgc2VjcmV0OiAnZTQyZDI3ZTNhYzU1MjFlYzRjYjY0MTE5ZmI4M2Q5ODAnXG59KTtcbiIsIlNlcnZpY2VDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zLnJlbW92ZSh7XG4gICAgc2VydmljZTogJ2dvb2dsZSdcbn0pO1xuXG5TZXJ2aWNlQ29uZmlndXJhdGlvbi5jb25maWd1cmF0aW9ucy5pbnNlcnQoe1xuICAgIHNlcnZpY2U6ICdnb29nbGUnLFxuICAgIGNsaWVudElkOiAnMzg3MzE2NTU0Nzk3LW40OXF2amRoODJ0aWEzZ2JoczQybjYyc3AyZjBtdDQxLmFwcHMuZ29vZ2xldXNlcmNvbnRlbnQuY29tJyxcbiAgICBzZWNyZXQ6ICdwa1VQejdROTlnbDJySW1NQlVKYTRCbkQnXG59KTtcbiIsIlxuUm9vbXMuYWxsb3coe1xuICAgIGluc2VydCAodXNlcklkLCBkb2MpIHtcbiAgICAgICAgcmV0dXJuICh1c2VySWQgJiYgZG9jLm93bmVyID09PSB1c2VySWQpO1xuICAgIH1cbn0pO1xuXG4vKiDstpTqsIAgKi9cbk1lc3NhZ2VzLmFsbG93KHtcbiAgICBpbnNlcnQgKHVzZXJJZCwgZG9jKSB7XG4gICAgICAgIHJldHVybiAodXNlcklkICYmIGRvYy5vd25lciA9PT0gdXNlcklkKTtcbiAgICB9XG59KTtcbiIsIlxuTWV0ZW9yLnN0YXJ0dXAoKCk9PntcblxuICAgIGlmKCFSb29tcy5maW5kT25lKHtfaWQ6XCJNZXRlb3JTY2hvb2xcIn0pKSB7XG5cbiAgICAgICAgLyrsgqzsmqnsnpAg65Ox66GdKi9cbiAgICAgICAgdmFyIHVzcjEgPSBBY2NvdW50cy5jcmVhdGVVc2VyKHtcbiAgICAgICAgICAgIHVzZXJuYW1lIDogXCLsmYDquIDsnbRcIixcbiAgICAgICAgICAgIGVtYWlsIDogXCJ3YWdnbGVAZ21haWwuY29tXCIsXG4gICAgICAgICAgICBwYXNzd29yZCA6IFwiMTIzNDU2NzhcIlxuICAgICAgICB9KTtcbiAgICAgICAgdmFyIHVzcjIgPSBBY2NvdW50cy5jcmVhdGVVc2VyKHtcbiAgICAgICAgICAgIHVzZXJuYW1lIDogXCLsiJjri6Tsn4HsnbRcIixcbiAgICAgICAgICAgIGVtYWlsIDogXCJwcGlsbGlwQGdtYWlsLmNvbVwiLFxuICAgICAgICAgICAgcGFzc3dvcmQgOiBcImRuZmxlbWZcIlxuICAgICAgICB9KTtcblxuICAgICAgICAvKuyxhO2MheuwqSDrk7HroZ0qL1xuICAgICAgICBSb29tcy5pbnNlcnQoe1xuICAgICAgICAgICAgX2lkIDogXCJNZXRlb3JTY2hvb2xcIixcbiAgICAgICAgICAgIG5hbWU6IFwiTWV0ZW9yU2Nob29sXCIsXG4gICAgICAgICAgICBvd25lcjogdXNyMSwgICAgICAgICAgICAvKiDrsKnsnqXsnYAg7JmA6riA7J20ICovXG4gICAgICAgICAgICB1c2VyTGlzdCA6IFt1c3IxLHVzcjJdLCAgICAvKiDssYTtjIXrsKkg7LC47Jes7J6QICovXG4gICAgICAgICAgICBjcmVhdGVkQXQgOiAobmV3IERhdGUoKSkuZ2V0VGltZSgpXG4gICAgICAgIH0pO1xuXG4gICAgfVxuXG59KTtcbiIsIlxuTWV0ZW9yLnB1Ymxpc2goXCJyb29tTGlzdFwiLGZ1bmN0aW9uKCl7XG4gICAgcmV0dXJuIFJvb21zLmZpbmQoKTtcbn0pO1xuXG5NZXRlb3IucHVibGlzaChcIm1lc3NhZ2VzXCIsZnVuY3Rpb24ocm9vbUlkLGNvdW50KXtcbiAgICBpZighcm9vbUlkKXtcbiAgICAgICAgY29uc29sZS5lcnJvcihcIuyxhO2MheuwqSDsi53rs4TsnpAg67aA7J6sXCIsY291bnQpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfWVsc2V7XG4gICAgICAgIHJldHVybiBNZXNzYWdlcy5maW5kKHtyb29tSWQ6cm9vbUlkfSx7c29ydDoge3RpbWVzdGFtcDogLTF9LCBsaW1pdDpjb3VudH0pO1xuICAgIH1cbn0pO1xuXG5NZXRlb3IucHVibGlzaChcInVzZXJEYXRhXCIsIGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gTWV0ZW9yLnVzZXJzLmZpbmQoKTtcbn0pO1xuLy9cbi8vIC8vIO2KueyglSDssYTtjIXrsKkgcHVibGlzaFxuLy8gTWV0ZW9yLnB1Ymxpc2goXCJyb29tXCIsZnVuY3Rpb24ocm9vbUlkKXtcbi8vICAgICByZXR1cm4gUm9vbXMuZmluZCh7X2lkOnJvb21JZH0pO1xuLy8gfSk7XG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuXG59KTtcblxuQWNjb3VudHMub25DcmVhdGVVc2VyKGZ1bmN0aW9uIChvcHRpb25zLCB1c2VyKSB7XG5cbiAgICBpZih1c2VyLnNlcnZpY2VzLmZhY2Vib29rKSB7XG4gICAgICB1c2VyLnVzZXJuYW1lID0gdXNlci5zZXJ2aWNlcy5mYWNlYm9vay5uYW1lO1xuICAgICAgdXNlci5lbWFpbHMgPSB1c2VyLnNlcnZpY2VzLmZhY2Vib29rLmVtYWlsO1xuICAgIH0gZWxzZSBpZih1c2VyLnNlcnZpY2VzLmdvb2dsZSkge1xuICAgICAgdXNlci51c2VybmFtZSA9IHVzZXIuc2VydmljZXMuZ29vZ2xlLm5hbWU7XG4gICAgICB1c2VyLmVtYWlscyA9IHVzZXIuc2VydmljZXMuZ29vZ2xlLmVtYWlsO1xuICAgIH1cbiAgICByZXR1cm4gdXNlcjtcbn0pO1xuIiwibW9kdWxlLmV4cG9ydHMgPSB7XG4gIHNlcnZlcnM6IHtcbiAgICBvbmU6IHtcbiAgICAgIC8vIFRPRE86IHNldCBob3N0IGFkZHJlc3MsIHVzZXJuYW1lLCBhbmQgYXV0aGVudGljYXRpb24gbWV0aG9kXG4gICAgICBob3N0OiAnNTQuMjUwLjQ0LjIzNCcsXG4gICAgICB1c2VybmFtZTogJ3VidW50dScsXG4gICAgICBwZW06ICcuLi93YWdnbGUxLnBlbSdcbiAgICAgIC8vIHBhc3N3b3JkOiAnc2VydmVyLXBhc3N3b3JkJ1xuICAgICAgLy8gb3IgbmVpdGhlciBmb3IgYXV0aGVudGljYXRlIGZyb20gc3NoLWFnZW50XG4gICAgfVxuICB9LFxuXG4gIGFwcDoge1xuICAgIC8vIFRPRE86IGNoYW5nZSBhcHAgbmFtZSBhbmQgcGF0aFxuICAgIG5hbWU6ICd3YWdnbGVDaGF0JyxcbiAgICBwYXRoOiAnLi4vJyxcblxuICAgIHNlcnZlcnM6IHtcbiAgICAgIG9uZToge30sXG4gICAgfSxcblxuICAgIGJ1aWxkT3B0aW9uczoge1xuICAgICAgc2VydmVyT25seTogdHJ1ZSxcbiAgICB9LFxuXG4gICAgZW52OiB7XG4gICAgICAvLyBUT0RPOiBDaGFuZ2UgdG8geW91ciBhcHAncyB1cmxcbiAgICAgIC8vIElmIHlvdSBhcmUgdXNpbmcgc3NsLCBpdCBuZWVkcyB0byBzdGFydCB3aXRoIGh0dHBzOi8vXG4gICAgICBST09UX1VSTDogJ2h0dHA6Ly9lYzItNTQtMjUwLTQ0LTIzNC5hcC1ub3J0aGVhc3QtMS5jb21wdXRlLmFtYXpvbmF3cy5jb20nLFxuICAgICAgTU9OR09fVVJMOiAnbW9uZ29kYjovL2pvZTEyMjA6YzE1OTc4OWNAZHMxMjE4OTgubWxhYi5jb206MjE4OTgvd2FnZ2xlY2hhdCcsXG4gICAgfSxcblxuICAgIC8vIHNzbDogeyAvLyAob3B0aW9uYWwpXG4gICAgLy8gICAvLyBFbmFibGVzIGxldCdzIGVuY3J5cHQgKG9wdGlvbmFsKVxuICAgIC8vICAgYXV0b2dlbmVyYXRlOiB7XG4gICAgLy8gICAgIGVtYWlsOiAnZW1haWwuYWRkcmVzc0Bkb21haW4uY29tJyxcbiAgICAvLyAgICAgLy8gY29tbWEgc2VwYXJhdGVkIGxpc3Qgb2YgZG9tYWluc1xuICAgIC8vICAgICBkb21haW5zOiAnd2Vic2l0ZS5jb20sd3d3LndlYnNpdGUuY29tJ1xuICAgIC8vICAgfVxuICAgIC8vIH0sXG5cbiAgICBkb2NrZXI6IHtcbiAgICAgIC8vIGNoYW5nZSB0byAnYWJlcm5peC9tZXRlb3JkOmJhc2UnIGlmIHlvdXIgYXBwIGlzIHVzaW5nIE1ldGVvciAxLjQgLSAxLjVcbiAgICAgIGltYWdlOiAnYWJlcm5peC9tZXRlb3JkOm5vZGUtOC40LjAtYmFzZScsXG4gICAgfSxcblxuICAgIC8vIFNob3cgcHJvZ3Jlc3MgYmFyIHdoaWxlIHVwbG9hZGluZyBidW5kbGUgdG8gc2VydmVyXG4gICAgLy8gWW91IG1pZ2h0IG5lZWQgdG8gZGlzYWJsZSBpdCBvbiBDSSBzZXJ2ZXJzXG4gICAgZW5hYmxlVXBsb2FkUHJvZ3Jlc3NCYXI6IHRydWVcbiAgfSxcblxuICBtb25nbzoge1xuICAgIHZlcnNpb246ICczLjQuMScsXG4gICAgc2VydmVyczoge1xuICAgICAgb25lOiB7fVxuICAgIH1cbiAgfVxufTtcbiJdfQ==
